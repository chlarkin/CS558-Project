# import numpy as np
# N=5
# data = np.zeros((N,2))

# print(data)

# tup = [(1,1,1), 1]
# print(tup)


list1 = [1,2,3,4,5,1]

print(list1.index(1))
