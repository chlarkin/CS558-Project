List of Files and their purpose

training.py
Simply run the file to see the results from training. Note that the model will not be saved anywhere as of now, and data must be in the correct folder already.

Here's an example of the final output:
Fold 1: Training Loss: 0.3162, Validation Loss: 0.2847, Accuracy: 88.16%
Fold 2: Training Loss: 0.3049, Validation Loss: 0.3085, Accuracy: 88.66%
Fold 3: Training Loss: 0.3103, Validation Loss: 0.3114, Accuracy: 87.89%
Fold 4: Training Loss: 0.3024, Validation Loss: 0.2814, Accuracy: 89.50%
Fold 5: Training Loss: 0.3056, Validation Loss: 0.3077, Accuracy: 88.84%